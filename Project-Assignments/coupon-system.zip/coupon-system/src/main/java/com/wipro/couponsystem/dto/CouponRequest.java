package com.wipro.couponsystem.dto;
import com.wipro.couponsystem.entity.DiscountType;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

public record CouponRequest(
        @NotBlank(message = "Coupon code is required")
        @Size(min = 3, max = 20, message = "Code must be 3 to 20 characters")
        String code,

        String description,

        @NotNull(message = "Discount type is required")
        DiscountType discountType,

        @NotNull(message = "Discount value is required")
        @Positive(message = "Discount value must be greater than 0")
        BigDecimal discountValue,

        @PositiveOrZero(message = "Minimum order amount cannot be negative")
        BigDecimal minOrderAmount,

        @Positive(message = "Max uses must be greater than 0")
        Integer maxUses,

        @FutureOrPresent(message = "Expiry date cannot be in the past")
        LocalDate expiryDate,

        Boolean active
) {}