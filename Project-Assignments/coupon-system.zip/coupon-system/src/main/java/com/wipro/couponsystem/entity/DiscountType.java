package com.wipro.couponsystem.entity;


public enum DiscountType {
    PERCENTAGE,   // e.g. 10 means 10% off
    FIXED         // e.g. 100 means 100 rupees off
}