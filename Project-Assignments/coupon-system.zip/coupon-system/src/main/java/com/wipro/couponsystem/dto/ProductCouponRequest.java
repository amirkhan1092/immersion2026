package com.wipro.couponsystem.dto;

import jakarta.validation.constraints.*;

public record ProductCouponRequest(
        @NotBlank(message = "Coupon code is required")
        String code,

        @NotNull(message = "Product id is required")
        Long productId,

        @NotNull(message = "Quantity is required")
        @Min(value = 1, message = "Quantity must be at least 1")
        Integer quantity
) {}