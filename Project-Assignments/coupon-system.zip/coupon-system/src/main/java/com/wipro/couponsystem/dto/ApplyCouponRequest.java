package com.wipro.couponsystem.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record ApplyCouponRequest(
        @NotBlank(message = "Coupon code is required")
        String code,

        @NotNull(message = "Order amount is required")
        @Positive(message = "Order amount must be greater than 0")
        BigDecimal orderAmount
) {}