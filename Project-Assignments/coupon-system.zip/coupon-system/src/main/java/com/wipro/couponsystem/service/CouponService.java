package com.wipro.couponsystem.service;

import com.wipro.couponsystem.client.ProductClient;
import com.wipro.couponsystem.dto.ApplyCouponRequest;
import com.wipro.couponsystem.dto.CouponRequest;
import com.wipro.couponsystem.dto.CouponResult;
import com.wipro.couponsystem.dto.ProductCouponRequest;
import com.wipro.couponsystem.dto.ProductResponse;
import com.wipro.couponsystem.exception.DuplicateResourceException;
import com.wipro.couponsystem.exception.InvalidCouponException;
import com.wipro.couponsystem.exception.ResourceNotFoundException;
import com.wipro.couponsystem.entity.Coupon;
import com.wipro.couponsystem.entity.DiscountType;
import com.wipro.couponsystem.repository.CouponRepository;

import feign.FeignException;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;



@Service
public class CouponService {

    private final CouponRepository repository;
    private final ProductClient productClient;

    public CouponService(CouponRepository repository, ProductClient productClient) {
        this.repository = repository;
        this.productClient = productClient;
    }
    
    
    @Transactional
    public CouponResult applyToProduct(ProductCouponRequest request) {
        ProductResponse product;
        try {
            product = productClient.getProduct(request.productId());
        } catch (FeignException.NotFound e) {
            throw new ResourceNotFoundException("Product not found with id " + request.productId());
        }

        BigDecimal orderAmount = product.price()
                .multiply(BigDecimal.valueOf(request.quantity()));

        // reuse the rules you already wrote (expiry, limits, minimum amount)
        return apply(new ApplyCouponRequest(request.code(), orderAmount));
    }
    
    
    
    
    
    

    // ---------- CRUD ----------

    public Coupon create(CouponRequest request) {
        String code = request.code().trim().toUpperCase();
        if (repository.existsByCodeIgnoreCase(code)) {
            throw new DuplicateResourceException("Coupon code already exists: " + code);
        }
        Coupon coupon = new Coupon();
        copyFields(request, coupon, code);
        coupon.setUsedCount(0);
        return repository.save(coupon);
    }

    public List<Coupon> getAll() {
        return repository.findAll();
    }

    public Coupon getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coupon not found with id " + id));
    }

    public Coupon getByCode(String code) {
        return repository.findByCodeIgnoreCase(code.trim())
                .orElseThrow(() -> new ResourceNotFoundException("Coupon not found with code " + code));
    }

    public Coupon update(Long id, CouponRequest request) {
        Coupon existing = getById(id);
        String code = request.code().trim().toUpperCase();
        if (!existing.getCode().equalsIgnoreCase(code) && repository.existsByCodeIgnoreCase(code)) {
            throw new DuplicateResourceException("Coupon code already exists: " + code);
        }
        copyFields(request, existing, code);
        return repository.save(existing);
    }

    public void delete(Long id) {
        repository.delete(getById(id));
    }

    // ---------- Business logic ----------

    /** Checks the coupon and calculates the discount, without using it up. */
    public CouponResult validate(ApplyCouponRequest request) {
        Coupon coupon = getByCode(request.code());
        BigDecimal discount = checkAndCalculate(coupon, request.orderAmount());
        return buildResult(coupon, request.orderAmount(), discount, "Coupon is valid");
    }

    /** Same checks as validate, then counts one use. */
    @Transactional
    public CouponResult apply(ApplyCouponRequest request) {
        Coupon coupon = getByCode(request.code());
        BigDecimal discount = checkAndCalculate(coupon, request.orderAmount());
        coupon.setUsedCount(coupon.getUsedCount() + 1);
        repository.save(coupon);
        return buildResult(coupon, request.orderAmount(), discount, "Coupon applied successfully");
    }

    private BigDecimal checkAndCalculate(Coupon coupon, BigDecimal orderAmount) {
        if (!Boolean.TRUE.equals(coupon.getActive())) {
            throw new InvalidCouponException("Coupon is not active");
        }
        if (coupon.getExpiryDate() != null && coupon.getExpiryDate().isBefore(LocalDate.now())) {
            throw new InvalidCouponException("Coupon has expired on " + coupon.getExpiryDate());
        }
        if (coupon.getMaxUses() != null && coupon.getUsedCount() >= coupon.getMaxUses()) {
            throw new InvalidCouponException("Coupon usage limit reached");
        }
        if (coupon.getMinOrderAmount() != null
                && orderAmount.compareTo(coupon.getMinOrderAmount()) < 0) {
            throw new InvalidCouponException(
                    "Minimum order amount for this coupon is " + coupon.getMinOrderAmount());
        }

        BigDecimal discount;
        if (coupon.getDiscountType() == DiscountType.PERCENTAGE) {
            discount = orderAmount.multiply(coupon.getDiscountValue())
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        } else {
            discount = coupon.getDiscountValue();
        }
        // discount can never be more than the order amount
        return discount.min(orderAmount);
    }

    private CouponResult buildResult(Coupon coupon, BigDecimal orderAmount,
                                     BigDecimal discount, String message) {
        return new CouponResult(coupon.getCode(), orderAmount, discount,
                orderAmount.subtract(discount), message);
    }

    private void copyFields(CouponRequest request, Coupon coupon, String code) {
        if (request.discountType() == DiscountType.PERCENTAGE
                && request.discountValue().compareTo(BigDecimal.valueOf(100)) > 0) {
            throw new InvalidCouponException("Percentage discount cannot be more than 100");
        }
        coupon.setCode(code);
        coupon.setDescription(request.description());
        coupon.setDiscountType(request.discountType());
        coupon.setDiscountValue(request.discountValue());
        coupon.setMinOrderAmount(request.minOrderAmount());
        coupon.setMaxUses(request.maxUses());
        coupon.setExpiryDate(request.expiryDate());
        coupon.setActive(request.active() == null ? Boolean.TRUE : request.active());
    }
}