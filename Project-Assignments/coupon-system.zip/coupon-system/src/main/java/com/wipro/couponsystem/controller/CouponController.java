package com.wipro.couponsystem.controller;



import com.wipro.couponsystem.dto.ApplyCouponRequest;
import com.wipro.couponsystem.dto.CouponRequest;
import com.wipro.couponsystem.dto.CouponResult;
import com.wipro.couponsystem.dto.ProductCouponRequest;
import com.wipro.couponsystem.entity.Coupon;
import com.wipro.couponsystem.service.CouponService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coupons")
public class CouponController {

    private final CouponService service;

    public CouponController(CouponService service) {
        this.service = service;
    }
    
    @PostMapping("/apply-to-product")
    public CouponResult applyToProduct(@Valid @RequestBody ProductCouponRequest request) {
        return service.applyToProduct(request);
    }

    @PostMapping
    public ResponseEntity<Coupon> create(@Valid @RequestBody CouponRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @GetMapping
    public List<Coupon> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Coupon getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @GetMapping("/code/{code}")
    public Coupon getByCode(@PathVariable String code) {
        return service.getByCode(code);
    }

    @PutMapping("/{id}")
    public Coupon update(@PathVariable Long id, @Valid @RequestBody CouponRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/validate")
    public CouponResult validate(@Valid @RequestBody ApplyCouponRequest request) {
        return service.validate(request);
    }

    @PostMapping("/apply")
    public CouponResult apply(@Valid @RequestBody ApplyCouponRequest request) {
        return service.apply(request);
    }
}