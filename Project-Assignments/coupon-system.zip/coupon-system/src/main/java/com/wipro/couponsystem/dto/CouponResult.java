package com.wipro.couponsystem.dto;

import java.math.BigDecimal;

public record CouponResult(
        String code,
        BigDecimal orderAmount,
        BigDecimal discountAmount,
        BigDecimal finalAmount,
        String message
) {}