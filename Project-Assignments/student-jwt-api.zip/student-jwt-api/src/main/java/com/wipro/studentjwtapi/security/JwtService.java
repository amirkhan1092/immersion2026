package com.wipro.studentjwtapi.security;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
public class JwtService {

    private final SecretKey key;
    private final long accessExpirationMs;
    private final long refreshExpirationMs;

    public JwtService(@Value("${app.jwt.secret}") String secret,
                      @Value("${app.jwt.access-expiration-ms}") long accessExpirationMs,
                      @Value("${app.jwt.refresh-expiration-ms}") long refreshExpirationMs) {
        // throws WeakKeyException if the secret is shorter than 32 bytes
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.accessExpirationMs = accessExpirationMs;
        this.refreshExpirationMs = refreshExpirationMs;
    }

    public String generateAccessToken(String username, String role) {
        return build(username, role, "access", accessExpirationMs);
    }

    public String generateRefreshToken(String username, String role) {
        return build(username, role, "refresh", refreshExpirationMs);
    }

    private String build(String username, String role, String type, long lifetimeMs) {
        Date now = new Date();
        return Jwts.builder()
                .subject(username)                                   // "sub": who
                .claim("role", role)                                 // custom claim
                .claim("type", type)                                 // access or refresh
                .issuedAt(now)                                       // "iat"
                .expiration(new Date(now.getTime() + lifetimeMs))    // "exp"
                .signWith(key)                                       // the tamper-proof seal
                .compact();                                          // header.payload.signature
    }

    /** Verifies the signature and expiry. Throws JwtException if anything is wrong. */
    public Claims parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public long getAccessExpirySeconds() {
        return accessExpirationMs / 1000;
    }
}