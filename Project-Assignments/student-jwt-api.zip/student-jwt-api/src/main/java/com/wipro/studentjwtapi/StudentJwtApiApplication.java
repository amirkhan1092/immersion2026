package com.wipro.studentjwtapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentJwtApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentJwtApiApplication.class, args);
	}

}
