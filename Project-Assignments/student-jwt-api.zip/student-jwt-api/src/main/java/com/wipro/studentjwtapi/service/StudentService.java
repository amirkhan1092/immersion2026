package com.wipro.studentjwtapi.service;





import com.wipro.studentjwtapi.exception.ResourceNotFoundException;
import com.wipro.studentjwtapi.model.Student;
import com.wipro.studentjwtapi.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public List<Student> search(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return repository.findAll();
        }
        return repository.findByNameContainingIgnoreCase(keyword.trim());
    }

    public Student getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id " + id));
    }

    public Student save(Student student) {
        return repository.save(student);
    }

    public void delete(Long id) {
        repository.delete(getById(id));
    }

    // true if ANOTHER student already uses this email
    public boolean isEmailTaken(Student student) {
        String email = student.getEmail() == null ? "" : student.getEmail().trim();
        return repository.findByEmailIgnoreCase(email)
                .filter(existing -> !existing.getId().equals(student.getId()))
                .isPresent();
    }
}