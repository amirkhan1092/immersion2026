package com.wipro.studentjwtapi.controller;



import com.wipro.studentjwtapi.dto.*;
import com.wipro.studentjwtapi.model.AppUser;
import com.wipro.studentjwtapi.repository.AppUserRepository;
import com.wipro.studentjwtapi.security.JwtService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final AppUserRepository users;
    private final PasswordEncoder encoder;

    public AuthController(AuthenticationManager authenticationManager, JwtService jwtService,
                          AppUserRepository users, PasswordEncoder encoder) {
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
        this.users = users;
        this.encoder = encoder;
    }

    @PostMapping("/auth/register")
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, String> register(@Valid @RequestBody RegisterRequest request) {
        if (users.existsByUsername(request.username())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Username already taken");
        }
        // role is ALWAYS USER. Never accept a role from the client
        users.save(new AppUser(request.username(), encoder.encode(request.password()), "USER"));
        return Map.of("message", "User registered");
    }

    @PostMapping("/auth/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        // checks the password with BCrypt. Throws BadCredentialsException if wrong
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.username(), request.password()));

        AppUser user = users.findByUsername(request.username()).orElseThrow();
        return new AuthResponse(
                jwtService.generateAccessToken(user.getUsername(), user.getRole()),
                jwtService.generateRefreshToken(user.getUsername(), user.getRole()),
                "Bearer",
                jwtService.getAccessExpirySeconds());
    }

    @PostMapping("/auth/refresh")
    public AuthResponse refresh(@Valid @RequestBody RefreshRequest request) {
        Claims claims;
        try {
            claims = jwtService.parse(request.refreshToken());
        } catch (JwtException | IllegalArgumentException e) {
            throw new BadCredentialsException("Invalid or expired refresh token");
        }
        if (!"refresh".equals(claims.get("type", String.class))) {
            throw new BadCredentialsException("This is not a refresh token");
        }

        // reload the user so a deleted account or a changed role is noticed here
        AppUser user = users.findByUsername(claims.getSubject())
                .orElseThrow(() -> new BadCredentialsException("User no longer exists"));

        return new AuthResponse(
                jwtService.generateAccessToken(user.getUsername(), user.getRole()),
                request.refreshToken(),
                "Bearer",
                jwtService.getAccessExpirySeconds());
    }

    // shows who the server thinks you are, based on your token
    @GetMapping("/me")
    public Map<String, Object> me(Authentication authentication) {
        List<String> roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();
        return Map.of("username", authentication.getName(), "roles", roles);
    }
}