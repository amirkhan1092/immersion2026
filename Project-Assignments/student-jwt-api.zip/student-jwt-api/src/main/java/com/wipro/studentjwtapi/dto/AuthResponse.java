package com.wipro.studentjwtapi.dto;



public record AuthResponse(String accessToken, String refreshToken, String tokenType, long expiresInSeconds) {}