package com.wipro.studentjwtapi.controller;


import com.wipro.studentjwtapi.model.Student;
import com.wipro.studentjwtapi.service.StudentService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@SecurityRequirement(name = "bearerAuth")   // only used by Swagger (Step 9)
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @GetMapping
    public List<Student> list(@RequestParam(required = false) String keyword) {
        return service.search(keyword);
    }

    @GetMapping("/{id}")
    public Student get(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Student create(@Valid @RequestBody Student student) {
        student.setId(null);
        if (service.isEmailTaken(student)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already used");
        }
        return service.save(student);
    }

    @PutMapping("/{id}")
    public Student update(@PathVariable Long id, @Valid @RequestBody Student student) {
        service.getById(id);                 // 404 if it doesn't exist
        student.setId(id);
        if (service.isEmailTaken(student)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already used");
        }
        return service.save(student);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}