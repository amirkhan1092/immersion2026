package com.wipro.studentjwtapi.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.studentjwtapi.model.Student;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByNameContainingIgnoreCase(String name);
    Optional<Student> findByEmailIgnoreCase(String email);
}