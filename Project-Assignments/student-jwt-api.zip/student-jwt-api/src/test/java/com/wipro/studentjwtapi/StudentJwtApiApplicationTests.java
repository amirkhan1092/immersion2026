package com.wipro.studentjwtapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentJwtApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
