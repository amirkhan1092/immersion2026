package com.wipro.vehicleinheritance.repository;



import com.wipro.vehicleinheritance.model.AbstractVehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VehicleRepository extends JpaRepository<AbstractVehicle, Long> {
 List<AbstractVehicle> findByBrandIgnoreCase(String brand);
}