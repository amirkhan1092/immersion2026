package com.wipro.vehicleinheritance.controller;



import com.wipro.vehicleinheritance.model.Bike;
import com.wipro.vehicleinheritance.service.VehicleService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bikes")
public class BikeController {

    private final VehicleService service;

    public BikeController(VehicleService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Bike create(@Valid @RequestBody Bike bike) {
        return service.createBike(bike);
    }

    // GET /api/bikes  or  GET /api/bikes?minCc=200
    @GetMapping
    public List<Bike> list(@RequestParam(required = false) Integer minCc) {
        return service.getBikes(minCc);
    }

    @GetMapping("/{id}")
    public Bike get(@PathVariable Long id) {
        return service.getBike(id);
    }

    @PutMapping("/{id}")
    public Bike update(@PathVariable Long id, @Valid @RequestBody Bike bike) {
        return service.updateBike(id, bike);
    }
}