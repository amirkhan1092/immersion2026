package com.wipro.vehicleinheritance.model;



import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Entity
@DiscriminatorValue("BIKE")
public class Bike extends AbstractVehicle {

    @NotNull(message = "Engine capacity is required")
    @Min(value = 50, message = "Engine capacity must be at least 50 cc")
    private Integer engineCc;

    @NotNull(message = "hasGear is required")
    private Boolean hasGear;

    public Integer getEngineCc() { return engineCc; }
    public void setEngineCc(Integer engineCc) { this.engineCc = engineCc; }

    public Boolean getHasGear() { return hasGear; }
    public void setHasGear(Boolean hasGear) { this.hasGear = hasGear; }

    @Override
    public String getType() { return "BIKE"; }

    @Override
    public int getWheels() { return 2; }

    @Override
    public BigDecimal getRentPerDay() {
        int cc = (engineCc == null) ? 0 : engineCc;
        return BigDecimal.valueOf(300)
                .add(BigDecimal.valueOf(cc).multiply(new BigDecimal("0.5")))
                .setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public String describe() {
        return getBrand() + " " + getModel() + ": " + engineCc + " cc bike, "
                + (Boolean.TRUE.equals(hasGear) ? "geared" : "gearless")
                + ", rent per day " + getRentPerDay();
    }
}