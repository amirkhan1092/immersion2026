package com.wipro.vehicleinheritance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleInheritanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleInheritanceApplication.class, args);
	}

}
