package com.wipro.vehicleinheritance.repository;



import com.wipro.vehicleinheritance.model.Bike;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BikeRepository extends JpaRepository<Bike, Long> {
 List<Bike> findByEngineCcGreaterThan(Integer engineCc);
}