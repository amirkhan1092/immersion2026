package com.wipro.vehicleinheritance.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Entity
@DiscriminatorValue("CAR")
public class Car extends AbstractVehicle {

    @NotNull(message = "Seats is required")
    @Min(value = 1, message = "Seats must be at least 1")
    @Max(value = 10, message = "Seats must be at most 10")
    private Integer seats;

    @NotNull(message = "Fuel type is required")
    @Enumerated(EnumType.STRING)
    private FuelType fuelType;

    public Integer getSeats() { return seats; }
    public void setSeats(Integer seats) { this.seats = seats; }

    public FuelType getFuelType() { return fuelType; }
    public void setFuelType(FuelType fuelType) { this.fuelType = fuelType; }

    @Override
    public String getType() { return "CAR"; }

    @Override
    public int getWheels() { return 4; }

    @Override
    public BigDecimal getRentPerDay() {
        int s = (seats == null) ? 0 : seats;
        return BigDecimal.valueOf(1000 + 150L * s).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public String describe() {
        return getBrand() + " " + getModel() + ": car with " + seats + " seats, "
                + fuelType + ", rent per day " + getRentPerDay();
    }
}