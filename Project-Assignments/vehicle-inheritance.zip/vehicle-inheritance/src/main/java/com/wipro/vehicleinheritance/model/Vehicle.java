package com.wipro.vehicleinheritance.model;


import java.math.BigDecimal;

public interface Vehicle {

    String getType();

    int getWheels();

    BigDecimal getRentPerDay();

    // default method: shared behavior that classes may override
    default String describe() {
        return getType() + " with " + getWheels() + " wheels, rent per day " + getRentPerDay();
    }
}