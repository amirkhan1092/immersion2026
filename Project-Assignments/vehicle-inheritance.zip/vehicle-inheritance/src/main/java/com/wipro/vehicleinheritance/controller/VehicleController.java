package com.wipro.vehicleinheritance.controller;


import com.wipro.vehicleinheritance.model.AbstractVehicle;
import com.wipro.vehicleinheritance.model.Vehicle;
import com.wipro.vehicleinheritance.service.VehicleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

 private final VehicleService service;

 public VehicleController(VehicleService service) {
     this.service = service;
 }

 @GetMapping
 public List<AbstractVehicle> all() {
     return service.getAll();
 }

 @GetMapping("/{id}")
 public AbstractVehicle get(@PathVariable Long id) {
     return service.getById(id);
 }

 // polymorphism: same call, different behavior depending on the real type
 @GetMapping("/{id}/describe")
 public Map<String, String> describe(@PathVariable Long id) {
     Vehicle vehicle = service.getById(id);          // typed as the INTERFACE
     return Map.of("description", vehicle.describe());
 }

 @GetMapping("/search")
 public List<AbstractVehicle> search(@RequestParam String brand) {
     return service.searchByBrand(brand);
 }

 @GetMapping("/summary")
 public Map<String, Long> summary() {
     return Map.of("total", service.countAll(),
                   "cars", service.countCars(),
                   "bikes", service.countBikes());
 }

 @DeleteMapping("/{id}")
 public ResponseEntity<Void> delete(@PathVariable Long id) {
     service.delete(id);
     return ResponseEntity.noContent().build();
 }
}