package com.wipro.vehicleinheritance.model;



public enum FuelType {
    PETROL, DIESEL, ELECTRIC, CNG, WATER
}