package com.wipro.vehicleinheritance.repository;


import com.wipro.vehicleinheritance.model.Car;
import com.wipro.vehicleinheritance.model.FuelType;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {
 List<Car> findByFuelType(FuelType fuelType);
}