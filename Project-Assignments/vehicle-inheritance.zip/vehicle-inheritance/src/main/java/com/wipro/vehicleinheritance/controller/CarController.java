package com.wipro.vehicleinheritance.controller;



import com.wipro.vehicleinheritance.model.Car;
import com.wipro.vehicleinheritance.model.FuelType;
import com.wipro.vehicleinheritance.service.VehicleService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cars")
public class CarController {

 private final VehicleService service;

 public CarController(VehicleService service) {
     this.service = service;
 }

 @PostMapping
 @ResponseStatus(HttpStatus.CREATED)
 public Car create(@Valid @RequestBody Car car) {
     return service.createCar(car);
 }

 // GET /api/cars  or  GET /api/cars?fuelType=ELECTRIC
 @GetMapping
 public List<Car> list(@RequestParam(required = false) FuelType fuelType) {
     return service.getCars(fuelType);
 }

 @GetMapping("/{id}")
 public Car get(@PathVariable Long id) {
     return service.getCar(id);
 }

 @PutMapping("/{id}")
 public Car update(@PathVariable Long id, @Valid @RequestBody Car car) {
     return service.updateCar(id, car);
 }
}