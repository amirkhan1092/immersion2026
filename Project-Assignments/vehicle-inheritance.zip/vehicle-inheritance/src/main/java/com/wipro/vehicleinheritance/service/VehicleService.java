package com.wipro.vehicleinheritance.service;



import com.wipro.vehicleinheritance.exception.ResourceNotFoundException;
import com.wipro.vehicleinheritance.model.*;
import com.wipro.vehicleinheritance.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {

    private final VehicleRepository vehicleRepository;
    private final CarRepository carRepository;
    private final BikeRepository bikeRepository;

    public VehicleService(VehicleRepository vehicleRepository,
                          CarRepository carRepository,
                          BikeRepository bikeRepository) {
        this.vehicleRepository = vehicleRepository;
        this.carRepository = carRepository;
        this.bikeRepository = bikeRepository;
    }

    // ---------- all vehicles (mixed types) ----------

    public List<AbstractVehicle> getAll() {
        return vehicleRepository.findAll();
    }

    public AbstractVehicle getById(Long id) {
        return vehicleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with id " + id));
    }

    public List<AbstractVehicle> searchByBrand(String brand) {
        return vehicleRepository.findByBrandIgnoreCase(brand.trim());
    }

    public void delete(Long id) {
        vehicleRepository.delete(getById(id));
    }

    // ---------- cars ----------

    public Car createCar(Car car) {
        car.setId(null);                    // the database generates the id
        return carRepository.save(car);
    }

    public List<Car> getCars(FuelType fuelType) {
        return fuelType == null ? carRepository.findAll() : carRepository.findByFuelType(fuelType);
    }

    public Car getCar(Long id) {
        return carRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Car not found with id " + id));
    }

    public Car updateCar(Long id, Car input) {
        Car car = getCar(id);
        copyCommon(input, car);
        car.setSeats(input.getSeats());
        car.setFuelType(input.getFuelType());
        return carRepository.save(car);
    }

    // ---------- bikes ----------

    public Bike createBike(Bike bike) {
        bike.setId(null);
        return bikeRepository.save(bike);
    }

    public List<Bike> getBikes(Integer minCc) {
        return minCc == null ? bikeRepository.findAll() : bikeRepository.findByEngineCcGreaterThan(minCc);
    }

    public Bike getBike(Long id) {
        return bikeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bike not found with id " + id));
    }

    public Bike updateBike(Long id, Bike input) {
        Bike bike = getBike(id);
        copyCommon(input, bike);
        bike.setEngineCc(input.getEngineCc());
        bike.setHasGear(input.getHasGear());
        return bikeRepository.save(bike);
    }

    // ---------- summary ----------

    public long countAll()  { return vehicleRepository.count(); }
    public long countCars() { return carRepository.count(); }
    public long countBikes(){ return bikeRepository.count(); }

    private void copyCommon(AbstractVehicle from, AbstractVehicle to) {
        to.setBrand(from.getBrand());
        to.setModel(from.getModel());
        to.setManufactureYear(from.getManufactureYear());
        to.setPrice(from.getPrice());
    }
}