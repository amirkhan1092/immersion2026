package com.wipro.vehicleinheritance.config;


import com.wipro.vehicleinheritance.model.*;
import com.wipro.vehicleinheritance.repository.BikeRepository;
import com.wipro.vehicleinheritance.repository.CarRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataInitializer implements CommandLineRunner {

    private final CarRepository cars;
    private final BikeRepository bikes;

    public DataInitializer(CarRepository cars, BikeRepository bikes) {
        this.cars = cars;
        this.bikes = bikes;
    }

    @Override
    public void run(String... args) {
        cars.save(car("Toyota", "Innova", 2022, "2200000", 7, FuelType.DIESEL));
        cars.save(car("Tata", "Nexon EV", 2024, "1600000", 5, FuelType.ELECTRIC));
        bikes.save(bike("Royal Enfield", "Classic 350", 2023, "200000", 350, true));
        bikes.save(bike("Honda", "Activa", 2023, "90000", 110, false));
    }

    private Car car(String brand, String model, int year, String price, int seats, FuelType fuel) {
        Car c = new Car();
        c.setBrand(brand);
        c.setModel(model);
        c.setManufactureYear(year);
        c.setPrice(new BigDecimal(price));
        c.setSeats(seats);
        c.setFuelType(fuel);
        return c;
    }

    private Bike bike(String brand, String model, int year, String price, int cc, boolean gear) {
        Bike b = new Bike();
        b.setBrand(brand);
        b.setModel(model);
        b.setManufactureYear(year);
        b.setPrice(new BigDecimal(price));
        b.setEngineCc(cc);
        b.setHasGear(gear);
        return b;
    }
}