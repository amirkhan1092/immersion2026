package com.wipro.vehicleinheritance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleInheritanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
