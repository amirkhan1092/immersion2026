package com.wipro.product.controller;




import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.wipro.product.entity.Product;
import com.wipro.product.exception.ResourceNotFoundException;
import com.wipro.product.service.ProductService;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    // CREATE
    @PostMapping
    public ResponseEntity<Product> create(@RequestBody Product product) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(product));
    }

    // READ all
    @GetMapping
    public List<Product> getAll() {
        return service.getAll();
    }

    // READ one
    @GetMapping("/{id}")
    public Product getById(@PathVariable Long id) throws ResourceNotFoundException {
        return service.getById(id);
    }
    

   
}