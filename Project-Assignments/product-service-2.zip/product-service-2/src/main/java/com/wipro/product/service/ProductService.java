package com.wipro.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.wipro.product.entity.Product;
import com.wipro.product.exception.ResourceNotFoundException;
import com.wipro.product.repository.ProductRepository;

@Service
public class ProductService {
	
	private final ProductRepository repository;

	public ProductService(@Autowired ProductRepository repository) {
		super();
		this.repository = repository;
	}
	
	public Product create(Product prod) {
		return repository.save(prod);
	}
	
	 public List<Product> getAll() {
	        return repository.findAll();
	    }
//
//	    public Product getById(Long id) throws ResourceNotFoundException {
//	        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + id));
//	    }
//	    
	    public Product getById(Long id) throws ResourceNotFoundException {
	        return repository.findById(id)
	                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + id));
	    }

	 

	    public void delete(Long id) throws ResourceNotFoundException {
	        repository.delete(getById(id));
	    }

	}
	
	


