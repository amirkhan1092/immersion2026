package com.wipro.product.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
public class Product {

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id; 
		
	
		private String name;
		
		private String description;
		
		private Integer quantity;
		
		private String category;
		
		
		

		public Product(Long id, String name, String description, Integer quantity, String category) {
			super();
			this.id = id;
			this.name = name;
			this.description = description;
			this.quantity = quantity;
			this.category = category;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public Integer getQuantity() {
			return quantity;
		}

		public void setQuantity(Integer quantity) {
			this.quantity = quantity;
		}

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}
		
		
}
