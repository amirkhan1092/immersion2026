package com.wipro.studentmanagement.controller;



import com.wipro.studentmanagement.model.Student;
import com.wipro.studentmanagement.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    // READ: list and search (USER and ADMIN)
    @GetMapping
    public String list(@RequestParam(required = false) String keyword,
                       Authentication authentication, Model model) {
        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        model.addAttribute("students", service.search(keyword));
        model.addAttribute("keyword", keyword);
        model.addAttribute("username", authentication.getName());
        model.addAttribute("isAdmin", isAdmin);
        return "students/list";
    }

    // CREATE: show empty form (ADMIN)
    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("title", "Add Student");
        return "students/form";
    }

    // UPDATE: show filled form (ADMIN)
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("student", service.getById(id));
        model.addAttribute("title", "Edit Student");
        return "students/form";
    }

    // CREATE and UPDATE: save (ADMIN)
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("student") Student student,
                       BindingResult result, Model model,
                       RedirectAttributes redirectAttributes) {

        if (service.isEmailTaken(student)) {
            result.rejectValue("email", "duplicate", "This email is already used");
        }
        if (result.hasErrors()) {
            model.addAttribute("title", student.getId() == null ? "Add Student" : "Edit Student");
            return "students/form";
        }

        boolean isNew = student.getId() == null;
        service.save(student);
        redirectAttributes.addFlashAttribute("message",
                isNew ? "Student added successfully" : "Student updated successfully");
        return "redirect:/students";
    }

    // DELETE (ADMIN)
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        service.delete(id);
        redirectAttributes.addFlashAttribute("message", "Student deleted");
        return "redirect:/students";
    }
}
