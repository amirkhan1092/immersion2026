package com.wipro.studentmanagement.config;



import com.wipro.studentmanagement.model.AppUser;
import com.wipro.studentmanagement.model.Student;
import com.wipro.studentmanagement.repository.AppUserRepository;
import com.wipro.studentmanagement.repository.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final AppUserRepository users;
    private final StudentRepository students;
    private final PasswordEncoder encoder;

    public DataInitializer(AppUserRepository users, StudentRepository students, PasswordEncoder encoder) {
        this.users = users;
        this.students = students;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) {
        if (!users.existsByUsername("admin")) {
            users.save(new AppUser("admin", encoder.encode("admin123"), "ADMIN"));
        }
        if (!users.existsByUsername("user")) {
            users.save(new AppUser("user", encoder.encode("user123"), "USER"));
        }
        if (students.count() == 0) {
            students.save(new Student("Arun Kumar", "arun@example.com", "Java Full Stack", 22));
            students.save(new Student("Priya Sharma", "priya@example.com", "Data Science", 21));
            students.save(new Student("Kavin Raj", "kavin@example.com", "Cloud Computing", 23));
        }
    }
}